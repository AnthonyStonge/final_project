## Controls

Use **WASD** to move arround, **LEFT CLICK** to shoot, **RIGHT CLICK** to spawn enemies, **1 -2** **key** to switch gun. **Space to SHIFT** to dash. If you're moving, will dash toward moving direction. If you're not moving will dash toward cursor.


Use **Numpad 7 - 8 - 9** to change game state.

## Known Bugs
Doesn't shoot with the right angle
Animation may throw an exception, still early in development
Going outside the map with the player will kill the game
